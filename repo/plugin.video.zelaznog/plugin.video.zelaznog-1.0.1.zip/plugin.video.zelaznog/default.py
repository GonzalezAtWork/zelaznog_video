# -*- coding: utf-8 -*-

""" zelaznog.net
    2015 zelaznog"""

import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,datetime,time
from resources.lib.net import Net
net=Net()

####################################################### CONSTANTES #####################################################

versao = '0.1'
addon_id = 'plugin.video.zelaznog'
MainURL = 'http://zelaznog.net/'
user_agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36'
selfAddon = xbmcaddon.Addon(id=addon_id)
mensagemok = xbmcgui.Dialog().ok
mensagemprogresso = xbmcgui.DialogProgress()
username = urllib.quote(selfAddon.getSetting('username'))
password = selfAddon.getSetting('password')
bitrate = urllib.quote(selfAddon.getSetting('bitrate'))

########################################################### PLAYER ################################################

def analyzer(user, url):
      mensagemprogresso.create('Zelaznog', 'Atualizando arquivos...')
      
      final_url = ''
      final_srt = ''
      final_image = ''
      final_filename = ''
      linkfinal = ''
      final = ''

      try:
            form_d = {'username':username,'password':password,'user':user,'video':url,'bitrate':bitrate}
            ref_data = {'Accept': '*/*', 'Content-Type': 'application/x-www-form-urlencoded','Origin': 'http://zelaznog.net', 'X-Requested-With': 'XMLHttpRequest', 'Referer': 'http://zelaznog.net/','User-Agent':user_agent}
            endlogin = MainURL + 'getVideo.php'
            final = net.http_POST(endlogin,form_data=form_d,headers=ref_data).content.encode('latin-1','ignore')
            final = final.replace('\u0026','&').replace('\u003c','<').replace('\u003e','>').replace('\\','')

            final_url = re.compile('"url":"(.+?)"').findall(final)[0]
            final_srt = re.compile('"subtitle":"(.+?)"').findall(final)[0]
            final_image = re.compile('"image":"(.+?)"').findall(final)[0]
            final_filename = re.compile('"file_name":"(.+?)"').findall(final)[0]
      except: pass

      mensagemprogresso.close()

      final_url = final_url.replace('\u0026','&').replace('\u003c','<').replace('\u003e','>').replace('\\','')
      final_srt = final_srt.replace('\u0026','&').replace('\u003c','<').replace('\u003e','>').replace('\\','')
      comecarvideo(url,final_url,legendas=final_srt)

def comecarvideo(name,url,legendas=None):
        playeractivo = xbmc.getCondVisibility('Player.HasMedia')
        item = urllib.unquote( urllib.unquote( name ) ).decode("utf-8")
        listitem = xbmcgui.ListItem(item)
        listitem.select(True)
        listitem.setPath(url)
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listitem)
        if legendas != None: 
            time.sleep(2)
            xbmc.Player().setSubtitles(legendas.encode("utf-8"))
     
def get_params():
      param=[]
      paramstring=sys.argv[2]
      if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                  params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                  splitparams={}
                  splitparams=pairsofparams[i].split('=')
                  if (len(splitparams))==2:
                        param[splitparams[0]]=splitparams[1]                 
      return param


params = get_params()
url = None
user = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: user=urllib.unquote_plus(params["user"])
except: pass

if url==None or len(url)<1:
      print "Versao Instalada: v" + versao
else: 
      analyzer(user, url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))